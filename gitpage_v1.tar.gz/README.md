개인 블로그 

with [Solo](http://chibicode.github.io/solo) Jekyll theme
